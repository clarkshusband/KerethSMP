#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
	// delete sidebar numbers
	if(
			gl_Position.x >= 0.95 && gl_Position.y >= -0.35 && // check if the position matches the sidebar
			vertexColor.g == 84.0/255.0 && vertexColor.g == 84.0/255.0 && vertexColor.r == 252.0/255.0 //&& // check if the color is the sidebar red color
			//gl_VertexID <= 10 // check if it's the first character of a string
		) {
		vertexColor.a = 0;
		//gl_Position = ProjMat * ModelViewMat * vec4(ScreenSize + 100.0, 0.0, 0.0); // move the vertices offscreen, idk if this is a good solution for that but vec4(0.0) doesnt do the trick for everyone
	}
	if(gl_VertexID >= 1 && gl_Position.y > -0.5 && gl_Position.y < 0.85 && gl_Position.x > 0.60 && gl_Position.x <= 1.0 && gl_Position.z < -0.2 && gl_Position.z > -0.3) {
		gl_Position.z = -1;
	}
}
